import './App.css';
import { Container } from 'react-bootstrap';
import Header from './components/Header';
import Footer from './components/Footer';

function App() {
  return (
    <div>
      <Header />
      <main className='py-3'>
      <Container>
      <table cellPadding={4}>
      <tr>
      <td>
      <iframe width="560" height="315" src="https://www.youtube.com/embed/rYizcMZFX-Y?si=mJskNHqiPjHDYYrN" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
      </td>
      <td>
      <iframe width="560" height="315" src="https://www.youtube.com/embed/QnykUEqAVoc?si=be_nD2fPRXDXhu89" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
      </td>
      </tr>

      <tr>
      <td>
      <iframe width="560" height="315" src="https://www.youtube.com/embed/ntYXj9W1Ez8?si=yKjWYJRCDIW6Y4a0" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
      </td>
      <td>
      <iframe width="560" height="315" src="https://www.youtube.com/embed/PCBUcSoiEu4?si=piOd5RAXuqayfL82" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
      </td>
      </tr>
      </table>
      </Container>
      </main>
      <Footer />
    </div>
  );
}

export default App;
